#!/bin/bash
#Tällä skriptillä voi luoda lisää koodeja 1000 kerrallaan sopivasta prefixistä
[ x == x`which zint` ] && echo "please install zint first" && exit
[ x == x$1 ] && echo "generate <base>, where EAN-8: XXXX000 is base." && exit
for TAIL in {0..999}; do
	CODE=`printf "%04d%03d" $1 ${TAIL}`
	zint -b 10 -d "${CODE}" --height=33.9 --small --filetype=SVG \
		-o ${CODE}.svg
	echo ${CODE}
done
