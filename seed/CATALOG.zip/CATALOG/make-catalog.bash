#!/bin/bash
# Varmista, että jokaista tuotetta kohden on 3 tiedostoa samassa kansiossa
# seuraavassa muodossa `0XXXXXX.ext`, joista mikin on:
# 0XXXXXX.svg  - Viivakoodi
# 0XXXXXX.webp - Tuotekuva
# 0XXXXXX.txt  - Kuvausteksti
#
# Aja tämä scripti seuraavasti `bash make-catalog.bash > catalog.html`
# Avaa catalog.html selaimella ja tulosta
#
# Siirrä vanhentuneet tuotteet (3 tiedostoa) jemmaan VANHAT-kansioon
# Ota uutta tuotetta varten koodi VAPAAT-kansiosta katso KATEGORIAT.TXT
# .webp kuva voi olla mikä vaan kuvasuhteella 1:1
# Tarkista, että tiedostojen alkuosat tämäävät.
#
# Katalogin päivityksen jälkeen zippaa koko kansiorakenne, lisää etuliitteeksi
# päivämäärä ja heitä driveen seuraavaa päivitystä varten.

echo "\
<!DOCTYPE html>
<html>
<head>
<style>
body {
	display: flex;
	flex-wrap: wrap;
}
.product {
	width: 20em;
	height: 10em;
	border: 0.125em solid black;
	display: flex;
	align-items: center;
	margin: 0.25em;
	break-inside: avoid;
}
.data {
	width: 10em;
	display: flex;
	align-items: center;
	flex-direction: column;
}
.pr-image {
	width: 9.5em;
	height: 9.5em;
	margin: 0.25em;
}
.pr-text {
	width: 9em;
	height: 4em;
	margin: 0.5em;
}
.pr-text > p{
	font-family: Arial;
	font-size: 1.25em;
	margin: 0;
}
.pr-barcode {
	width: 9.5em;
	height: 4.5em;
	margin: 0.25em;
}

</style>
</head>
<body>
"
for code in ${CATALOG_DIR}*.svg; do
	code=${code%.*}
	echo "<div id=\"${code}\" class=\"product\">"
	echo "  <img src=\"${code}.webp\" class=\"pr-image\">"
	echo "  <div class=\"data\">"
	echo "	  <div class=\"pr-text\"><p>$(cat ${code}.txt)</p></div>"
	echo "	  <img src=\"${code}.svg\" class=\"pr-barcode\">"
	echo "  </div>"
	echo "</div>"
done
echo "
</body>
</html>\
"