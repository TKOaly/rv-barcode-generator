#!/bin/bash
# Tällä skriptillä luodaan sivullinen vapaita koodeja kustakin kategoriasta.
# Skripti ajetaan samaan tapaan kuin make-catalog eli:
# bash make-freecodes.bash > freecodes.html

echo "\
<!DOCTYPE html>
<html>
<head>
<style>
body {
	display: flex;
	flex-wrap: wrap;
}
.product {
	width: 20em;
	height: 10em;
	border: 0.125em solid black;
	display: flex;
	align-items: center;
	margin: 0.25em;
	break-inside: avoid;
}
.data {
	width: 10em;
	display: flex;
	align-items: center;
	flex-direction: column;
}
.pr-image {
	width: 9.5em;
	height: 9.5em;
	margin: 0.25em;
}
.pr-text {
	width: 9em;
	height: 4em;
	margin: 0.5em;
}
.pr-text > p{
	font-family: Arial;
	font-size: 1.25em;
	margin: 0;
}
.pr-barcode {
	width: 9.5em;
	height: 4.5em;
	margin: 0.25em;
}

</style>
</head>
<body>
"

for line in \
		"00002?? Suklaat" \
		"00003?? Karkit" \
		"00004?? Keksit" \
		"00005?? Jäätelöt" \
		"00006?? Patukat" \
		"00007?? Puurot" \
		"00008?? _varalla_" \
		"00009?? Muut" ; do

	for code in `ls VAPAAT/${line% *}.svg | head -5`; do
		code=${code%.*}
		echo "<div id=\"${code}\" class=\"product\">"
		echo "  <div class=\"pr-image\"></div>"
		echo "  <div class=\"data\">"
		echo "	  <div class=\"pr-text\"><p>${line#* }</p></div>"
		echo "	  <img src=\"${code}.svg\" class=\"pr-barcode\">"
		echo "  </div>"
		echo "</div>"
	done
done

echo "
</body>
</html>\
"