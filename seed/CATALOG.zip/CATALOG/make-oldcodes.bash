#!/bin/bash
# Tämä on lähes sama kuin make-catalog.bash. Lue siis infot sieltä.
# Erotuksena make-catalog.bash skriptiin tämä koostaa kattalogin tuotteista,
# jotka on poistunut myynnistä siis VANHAT-kansiossa.
#
# Suoritus samaan tapaan suoraan CATALOG-juuressa:
# bash make-oldcodes.bash > oldcodes.html

CATALOG_DIR=VANHAT/
. make-catalog.bash
